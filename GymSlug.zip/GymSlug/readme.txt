breakable seaweed env changed so that seaweed strength can be specified
Purpose: 
Test trained policy's behavior under different seaweed strength.
20210823
