import numpy as np 


grid = np.mgrid[0.2:0.8:3j, 0.2:0.8:3j].reshape(2, -1).T
print(grid[1], type(grid[1]))